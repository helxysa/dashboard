function showSection(sectionId) {
  // Hide all sections
  document.querySelectorAll('.section').forEach(section => {
    section.classList.add('hidden');
  });
  
  // Show selected section
  document.getElementById(sectionId).classList.remove('hidden');
}

// Initialize dashboard as default view
document.addEventListener('DOMContentLoaded', () => {
  showSection('dashboard');
});